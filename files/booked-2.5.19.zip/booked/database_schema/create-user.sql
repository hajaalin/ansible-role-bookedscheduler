
GRANT ALL on phpscheduleit2.* to 'schedule_user'@'127.0.0.1' identified by 'password';