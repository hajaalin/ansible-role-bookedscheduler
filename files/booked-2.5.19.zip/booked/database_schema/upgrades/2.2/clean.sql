SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `custom_attributes`;

SET foreign_key_checks = 1;